# Technoxian_2023_Arduino_Micromouse

#### Components
Arduino nano

TB6612FNG

Array of 5 IR sensors

2 600 rpm micro metal gear motors


#### Videos
Test Maze Run (youtube) - https://www.youtube.com/watch?v=6baHDssunZ4

Test Maze Run (instagram) - https://www.instagram.com/reel/CvSZLGBN-_r/

Simulator Run, single maze multiple runs - https://www.youtube.com/watch?v=V2KSZHkaBQY

Simulator Run, multiple mazes single run - https://drive.google.com/file/d/1eNVqJOWuEcbgEQmEDOBoLha9FvPk7lvz/view?usp=sharing
