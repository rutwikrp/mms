#ifndef globals_h
#define globals_h

#include <stdint.h>

// Direction constants
#define north 0
#define east 1
#define south 2
#define west 3

// Sensor positions
#define leftSensor 0
#define diagonalLeftSensor 1
#define centreSensor 2
#define diagonalRightSensor 3
#define rightSensor 4

// Threshold for detecting walls
#define wallThreshold 120

// Pin definitions
#define sensor_On_Pin 17
#define button 9

// Motor driver pins for L298
const int AIN1 = 8;
const int AIN2 = 9;
const int PWMA = 5;
const int BIN1 = 10;
const int BIN2 = 11;
const int PWMB = 6;
// const int STBY = 19;

// Ultrasonic sensor pins
const int trigPinForward = 4;
const int echoPinForward = 7;
const int trigPinLeft = 12;
const int echoPinLeft = 13;
const int trigPinRight = 2;
const int echoPinRight = 3;

// Utility macros
#define absolute(number) (((number) > 0)? (number) : (-(number)))
#define minimum(num1, num2) (((num1) < (num2))? (num1) : (num2))

// Matrix macros
#define linearise(row, col) (row * cols + col)
#define delineariseRow(location) (location / cols)
#define delineariseCol(location) (location % cols)

// Wall macros
#define distance(loc1, loc2) (absolute(delineariseRow(loc1) - delineariseRow(loc2)) + absolute(delineariseCol(loc1) - delineariseCol(loc2)))
#define markWall(location, direction) (floodArray[location].neighbours |= 1 << direction)
#define wallExists(location, direction) (floodArray[location].neighbours & (1 << direction))

// Neighbour macros
#define getNeighbourLocation(location, direction) ((uint8_t)((short)location + cellDirectionAddition[direction]))  // Calculates the location of neighbour
#define getNeighbourDistanceIfAccessible(location, direction) (floodArray[getNeighbourLocation(location, direction)].flood)
#define getNeighbourDistance(location, direction) (wallExists(location, direction) ? 255 : getNeighbourDistanceIfAccessible(location, direction))

// Direction macros
#define updateDirection(currentDirection, turn) *currentDirection = (*currentDirection + turn) % 4  // Updates the passed direction

// Cell structure to store flood value, wall neighbors, and visit status
struct cell {
  uint8_t flood;
  uint8_t neighbours;
  uint8_t visited;
};

// External variable declarations
extern struct cell floodArray[]; // 1D array of cell structures

extern const uint8_t rows, cols;

extern uint8_t startCell, startDir, targetCells[], currentCell;

extern uint8_t *values[];

extern int sensorValue[];

extern long newPosition1, newPosition2, oldPosition1, oldPosition2;

// Function declarations
void alignFront();
void turn(int angle, int speed);
void moveForward(long blocks, int speed);

#endif
