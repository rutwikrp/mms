// save_maze.h

#ifndef save_maze_h
#define save_maze_h

void updateMazeValuesFromEEPROM(void);
void updateMazeValuesInEEPROM(void);
void resetMazeValuesInEEPROM(void);

#endif
